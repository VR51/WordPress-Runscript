<?php

/*
	Plugin Name: Enable WP Database Tools
	Plugin URI: https://perishablepress.com/wordpress-plugin-enable-database-tools/
	Description: Enables WP Database Optimization and Repair Tools. Visit the Dashboard for shortcut link.
	Author: Jeff Starr
	Author URI: http://monzilla.biz/
	Donate link: http://m0n.co/donate
	Requires at least: 3.0
	Tested up to: trunk
	Version: 1.0
	License: GPL v2 or later
	Usage: Upload, activate, and visit the Dashboard for a shortcut link to the database tools page.
*/

if (!defined('ABSPATH')) die();

define('WP_ALLOW_REPAIR', true);

function shapeSpace_add_db_tools_shortcut() { ?>
	
	<p>Yo! Click the following link to optimize/repair your database:</p>
	<p><a target="_blank" href="<?php echo get_admin_url(); ?>maint/repair.php"><?php echo get_admin_url(); ?>maint/repair.php</a></p>
	<p><strong>Remember to deactivate the plugin</strong> when done optimizing!</p>
	
<?php }

function shapeSpace_add_dashboard_widgets() {
	wp_add_dashboard_widget('shapeSpace_add_db_tools_shortcut', 'Optimize/Repair Database', 'shapeSpace_add_db_tools_shortcut');
}
add_action('wp_dashboard_setup', 'shapeSpace_add_dashboard_widgets');
